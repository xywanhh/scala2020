package com.itheima.demo01_oop

//人类, 实体类.
class Person {

}
