package com.itheima.demo07_main

//案例: 通过继承App特质的方式, 定义程序的主入口.
object ClassDemo02 extends App{
  println("Hello, Scala123!")
}
