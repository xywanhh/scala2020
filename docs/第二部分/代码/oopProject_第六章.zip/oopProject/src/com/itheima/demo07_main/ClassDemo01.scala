package com.itheima.demo07_main

//案例: 演示通过main方法定义程序的主入口.
object ClassDemo01 {

  def main(args: Array[String]): Unit = {
    println("Hello, Scala!")
  }
}
